#include "user.h"
#include "stat.h"
#include "types.h"

int
main(int args, char *argv[])
{
   int pid;
   pid = atoi(argv[1]);
   ps(pid);
   exit();
}
